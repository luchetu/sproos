<?php
namespace App\Exceptions;
 
use Exception;
 
class SocialAuthException extends Exception
{
 
}
 