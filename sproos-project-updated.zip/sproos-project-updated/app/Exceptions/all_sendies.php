<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class all_sendies extends Model
{
     public function seller()
    {
        return $this->belongsToMany('App\seller');
    }
}
