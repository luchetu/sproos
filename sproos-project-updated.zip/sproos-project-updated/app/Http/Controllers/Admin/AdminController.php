<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Seller;
use App\Products;
use App\Http\Controllers\Controller;
use App\Model\admin\categories;
use DB;
use App\User;


class AdminController extends Controller
{
    /* Restricts access to only the admin */
    public function __construct()
	{
	    $this->middleware('auth:admin');
	}
	
    /*
    Controll actions of the admin
    */

    public function manage(){
        #this is the first page that will appear
        #shows various options in summary:
        # - Featured products
        # - top banner
        # - categories
        # - top sellers
        return('Manage your sites');
    }
    public function deactivate($id){
     $deactivate = Seller::find($id);
    if($deactivate) {
    $deactivate->activated= 0;
    $deactivate->save();
}
return back();
}
public function deactivate_user($id){
     $deactivate = User::find($id);
    if($deactivate) {
    $deactivate->activated= 0;
    $deactivate->save();
}
     return back();
    }
     public function cancel($id){
     $cancel= Products::find($id);
    if( $cancel) {
    $cancel->featured= 0;
    $cancel->save();
}
      return back();
    }

    public function confirm($id){
     $confirm= Products::find($id);
    if($confirm) {
    $confirm->featured= 3;
    $confirm->save();
}
     return back();
    }
     public function activate($id){
    $activated = Seller::find($id);
    if($activated) {
    $activated->activated= 2;
    $activated->save();
}
   return back();
    }
 public function activate_user($id){
    $activated = User::find($id);
    if($activated) {
    $activated->activated= 2;
    $activated->save();
}
     return back();
    }
    public function sellers(){
         $sellers = DB::table('sellers')
                  ->get();
        return view('admin/sellers',compact('sellers'));
    }
 public function seller_products($id){
        #Manage site sellers
        #top sellers
        #All sellers
         $products = DB::table('products')
                  ->where('seller_id',$id)
                  ->get();
        return view('admin/seller_products',compact('products'));
    }
    public function revenue(){
        #manage site revenue from products and sellers
        return ('Manage the site revenue');

    }
public function customers()
    {
        $sellers = Seller::all();
        $products = products::all();
        $users = User::all();
        return view('admin/customers',compact('products','sellers','users','orders'));
    }

    public function customerDetails($id)
    {
        
        $user = User::findOrFail($id);
        $orders = DB::table('order_details')
        ->leftJoin('products', 'products.id', '=', 'order_details.product_id')
        ->leftJoin('orders', 'orders.unique_order_id', '=', 'order_details.unique_order_id')
       ->where('order_details.user_id', '=', $id)
        ->get();
        return view('admin/customers-details',compact('products','sellers','user','orders'));
    }
    public function homePage(){
        $categories = categories::all();
        #manage the site homepage
        #by default, returns to admin homepage settings
        return view('admin/home-page',compact('categories'));
    }

    public function featuredProducts(){
        #manage the featured products
        return view('admin/featured-products');

    }

    # Featured page

    # categories

    #top sellers

    # banner


}
