<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Model\Admin\subcategories;
use App\types;
use App\Model\Admin\products;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;

class TypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $types = types::all();
        return view('admin.viewTypes',compact('types'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         $types = types::all();
        return view('admin.types',compact('$types'));    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'title' => 'required',
            'description' => 'required',
            'image' => 'image|nullable|max:1999|required',
            ]);

        if ($request->hasFile('image')) 
        {
            //Upload the image
            $imageName = Storage::disk('uploads')->putFile('types',$request->file('image'));
        } else
        {
            return 'Please select a product image';
        }

        $type = new types;
        $type->title = $request->title;
        $type->description = $request->description;
        $type->slug = $request->slug;
        $type->image = $imageName;
        $type->save();
        return redirect(route('type.index'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
         $types = types::where('id',$id)->first();
        return view('admin.edittypes',compact('types'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $this->validate($request,[
            'title' => 'required',
            'description' => 'required',
            'image' => 'image|nullable|max:1999',
            ]);

        $types = types::find($id);
        if ($request->hasFile('image')) 
        {
            //Upload the image
            $imageName = Storage::disk('uploads')->putFile('types',$request->file('image'));
            $ctype->image = $imageName;
        }
        $type->title = $request->title;
        $type->description = $request->description;
        $type->slug = $request->slug;
        $type->save();
        return redirect(route('type.index'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $type = types::findOrFail($id);
        $imageName = $type->image; 
        /* Delete the image from storage */
        Storage::disk('uploads')->delete($imageName);
        types::where('id',$id)->delete();   
        return redirect()->back();
    }
}
