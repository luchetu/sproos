<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Admin\categories;

use Gloudemans\Shoppingcart\Facades\Cart; // for cart lib
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use App\shoppingCart;
use App\Products;

use DB;

class CartController extends Controller
{
          
    public function destroy($id){
      Cart::remove($id);
      return back(); // will keep same page
  }

 public function add_cart($id){
        $products = DB::table('products')->where('id',$id)->first(); // get prodcut by id
       Cart::add(array(
            'id' => $products->id,
            'name' => $products->name,
            'qty' => 1,
            'price' => $products->price,
            'options' =>
             array('seller_id'=>$products->seller_id,'img' => $products->image,),
            ));
       
         return back();
    }
     public function shop_add_cart(Request $request){
      if ($request->color!=null)
      {
        $selected_color=$request->color;
      }
       else{
       $selected_color="No color";
       }

        if ($request->size!=null)
      {
        $selected_size=$request->size;
      }
       else{
       $selected_size="No size";
       }
              Cart::add(array(
            'id' => $request->id,
            'name' => $request->name,
            'qty' => 1,
            'price' => $request->price,
            'options' =>
             array('seller_id'=>$request->seller_id,'img' => $request->image,'color' => $selected_color,'size' => $selected_size,),
            ));
       
         return back();
    }
      public function updateCart(Request $request, $rowId)
    {
       $rowId = $rowId;
         
    Cart::update($rowId, $request->qty);
          }
    public function cart(){
        $cartItems = Cart::content();
       $categories = categories::all();
      return view('front.checkout.cart',compact('cartItems','carts','categories'));
   }
  
}