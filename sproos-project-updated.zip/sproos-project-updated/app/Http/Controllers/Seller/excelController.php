<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class excelController extends Controller
{
    //
}
