<?php

namespace App\Http\Controllers;
use App\User;
use Auth;
use Socialite;

use Illuminate\Http\Request;
use App\Exceptions\SocialAuthException;

class SocialAuthController extends Controller
{
    protected $redirectTo = '/account-profile/#';
     /**
     * Redirect the user to the OAuth Provider.
     *
     * @return Response
     */
    public function redirectToProvider($provider)
    {
        return Socialite::driver($provider)->redirect();
    }
  /**
     * Obtain the user information from provider.  Check if the user already exists in our
     * database by looking up their provider_id in the database.
     * If the user exists, log them in. Otherwise, create a new user then log them in. After that 
     * redirect them to the authenticated users homepage.
     *
     * @return Response
     */
    public function handleProviderCallback($provider)
    {
        #$user = Socialite::driver($provider)->user();

        try {
            $user = Socialite::driver($provider)->user();
        } catch(\GuzzleHttp\Exception\ClientException $e) {
            return redirect('/login')->with(['err'=>['OOPS! An error occurred while trying to sync with your Facebook account. Please try again.']]);
        }

        #check if the provider is facebook
            #check if the user already exists using provided email
                #if he/ she exists, ask him/her to login using password

                #if does not exist, create a new user and log him in 

        $authUser = $this->findOrCreateUser($user, $provider);
        Auth::guard('buyer')->login($authUser, true);
        return redirect($this->redirectTo);
    }

    /**
     * If a user has registered before using social auth, return the user
     * else, create a new user object.
     * @param  $user Socialite user object
     * @param $provider Social auth provider
     * @return  User
     */
    public function findOrCreateUser($user, $provider)
    {
        switch ($provider) {
            case 'facebook':
                $authUser = User::where('email', $user->email)->first();
                if ($authUser) {
                    return $authUser;
                }
                return User::create([
                    'first_name'     => $user->name,
                    'last_name'     => $user->name,
                    'email'    => $user->email,
                    'provider' => $provider,
                    'provider_id' => $user->id
                ]);
                break;

             case 'google':
                $authUser = User::where('email', $user->email)->first();
                if ($authUser) {
                    return $authUser;
                }
                return User::create([
                    'first_name'     => $user->name,
                    'last_name'     => $user->name,
                    'email'    => $user->email,
                    'provider' => $provider,
                    'provider_id' => $user->id
                ]);
                break;

            case 'twitter':
                $authUser = User::where('email', $user->email)->first();
                if ($authUser) {
                    return $authUser;
                }
                return User::create([
                    'first_name'     => $user->name,
                    'last_name'     => $user->name,
                    'provider' => $provider,
                    'email'    => $user->email,
                    'provider_id' => $user->id
                ]);
                break;
            
            default:
                return redirect('/login');
                break;
        }
        
    }
}
