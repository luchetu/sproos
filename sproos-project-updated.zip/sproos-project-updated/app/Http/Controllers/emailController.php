<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Mail\OrderShipped;
use Illuminate\Support\Facades\Auth;
use App\Model\admin\categories;

use Mail\contact;
use Gloudemans\Shoppingcart\Facades\Cart; // for cart lib
use App\Http\Requests\ContactFormRequest;
use DB;
use Redirect;

class emailController extends Controller
{
    /**
     * Show the application sendMail.
     *
     * @return \Illuminate\Http\Response
     */
    public function sendMail()
    {
    	$content = [
    		'title'=> 'Itsolutionstuff.com mail', 
    		'body'=> 'The body of your message.',
    		'button' => 'Click Here'
    		];

    	$receiverAddress = 'your email';

    	Mail::to($receiverAddress)->send(new OrderShipped($content));

    	dd('mail send successfully');
    }
    public function create()
    {
        return view('about.contact');
    }
     
    public function ask(ContactFormRequest $request)
    {
       $data=array( 
            'your_subject' =>$request->get('your_subject'),
            'your_category' => $request->get('your_category'),
            'your_question' =>$request->get('your_question'),
            'your_email' =>$request->get('your_email'),
            'your_name' =>$request->get('your_name')
       );
         \Mail::send('emails.faqs',$data,
       
   function($message) use($data)
    {
        $message->from($data['your_email']);
        $message->to('humluchetu@gmail.com');
        $message->subject($data['your_subject']);
 });

  return \Redirect::route('faqs')->with('send', 'Thanks for contacting us!');
}
 public function sproos(Request $request)
    {
        $this->validate($request, [
        'your_subject' => 'required',
        'your_message' => 'required',
        'your_email' => 'required',
        'your_name' => 'required',
    ]);
       $data=array( 
          'your_subject' =>$request->your_subject,
          'your_message' =>$request->your_message,
           'your_email' =>$request->your_email,
           'your_name' =>$request->your_name
       );

         \Mail::send('emails.contact',$data,
       
   function($message) use($data)
    {
        $message->from($data['your_email']);
        $message->to('humluchetu@gmail.com');
        $message->subject($data['your_subject']);
 });

  return \Redirect::route('contact')->with('send', 'Thanks for contacting us!');
}
public function order(){
    //send email to customer after payment has been made
    $status = DB::table('orders')->where('user_id', Auth::guard('buyer')->user()->id)->value('status');
    $tracking=session()->get('order_id');
    if($status="PENNDING"){
    $fetch_order =DB::table('orders')
        ->leftjoin('products', 'orders.product_id', '=', 'products.id')
        ->leftjoin('users', 'orders.user_id', '=', 'users.id')
        ->leftjoin('sellers', 'orders.seller_id', '=', 'sellers.id')
        ->select('orders.tax as tax','orders.unique_order_id as order_id','orders.price as price','orders.total_price as total','orders.unique_order_id as order_id','products.name as product_name','products.image as image','sellers.email as seller_email','users.email as buyer_email')
        ->where('unique_order_id', $tracking)
        ->get();

        array($fetch_order);
$orders=get_object_vars($fetch_order);
        
    \Mail::send('emails.buyer_order', ["orders"=>$orders],   
   function($message) use($orders)
    {
        $message->from('humluchetu@gmail.com');
       
        $message->to(Auth::guard('buyer')->user()->email);
      
        $message->subject('Your order has been confirmed');
    });

}
return $this->checkoutFinal();
}
public function test(){
    //send email to customer after payment has been made
    $status = DB::table('orders')->where('user_id', Auth::guard('buyer')->user()->id)->value('status');
    $tracking="5D213C991A";
    if($status="PENNDING"){
    $fetch_order =DB::table('orders')
        ->leftjoin('products', 'orders.product_id', '=', 'products.id')
        ->leftjoin('users', 'orders.user_id', '=', 'users.id')
        ->leftjoin('sellers', 'orders.seller_id', '=', 'sellers.id')
        ->select('orders.tax as tax','orders.unique_order_id as order_id','orders.price as price','orders.total_price as total','orders.unique_order_id as order_id','products.name as product_name','products.image as image','sellers.email as seller_email','users.email as buyer_email')
        ->where('unique_order_id', $tracking)
        ->get();

        array($fetch_order);
$orders=get_object_vars($fetch_order);
        
    \Mail::send('emails.buyer_order', ["orders"=>$orders],   
   function($message) use($orders)
    {
        $message->from('humluchetu@gmail.com');
       
        $message->to(Auth::guard('buyer')->user()->email);
      
        $message->subject('Your order has been confirmed');
    });

}
return $this->checkoutFinal();
}
 public function checkoutFinal() 
    {
           Cart::destroy();
          
       \Session::flash('done', 'Payments successfull!');
        return view('front.checkout.checkout-complete');
    }

public function show_contact(){
    $categories = categories::all();
     $cartItems = Cart::content();
    return view('front.contact',compact('categories','cartItems'));
}
}