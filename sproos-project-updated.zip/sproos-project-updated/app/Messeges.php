<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Messeges extends Model
{
    //
}
