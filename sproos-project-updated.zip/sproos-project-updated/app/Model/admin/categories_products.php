<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class categories_products extends Model
{
    //
}
