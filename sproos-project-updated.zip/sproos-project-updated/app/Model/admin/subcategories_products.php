<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class subcategories_products extends Model
{
    //
}
