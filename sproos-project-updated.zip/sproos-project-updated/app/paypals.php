<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class paypals extends Model
{
    //
}
